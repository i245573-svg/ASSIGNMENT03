const LegacyVault = artifacts.require("LegacyVault");

module.exports = async function (deployer, network, accounts) {
  // Deploy the LegacyVault smart contract
  await deployer.deploy(LegacyVault);

  const instance = await LegacyVault.deployed();
  console.log(`LegacyVault deployed on network [${network}] at address: ${instance.address}`);
};