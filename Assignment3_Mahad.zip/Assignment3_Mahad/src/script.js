const CONTRACT_ADDRESS = "0x9181C72b37E39e6940472390F6fc1AA4152049be";

const ABI = [
  "function createVault(address _beneficiary, uint256 _checkInIntervalSeconds) external payable returns (uint256)",
  "function pingOrClaim(uint256 _vaultId) external",
  "function getVaultDetails(uint256 _vaultId) external view returns (address owner, address beneficiary, uint256 balance, bool isClaimable, bool claimed)",
  "function secondsUntilClaimable(uint256 _vaultId) external view returns (uint256)",
  "event VaultCreated(uint256 indexed vaultId, address indexed owner, address indexed beneficiary, uint256 amount, uint256 interval)"
];

let provider, signer, contract, timer;

document.addEventListener("DOMContentLoaded", () => {
  const connectBtn = document.getElementById("connectBtn");
  if (connectBtn) {
    connectBtn.onclick = async () => {
      if (!window.ethereum) return alert("Please install MetaMask!");
      try {
        provider = new ethers.BrowserProvider(window.ethereum);
        signer = await provider.getSigner();
        contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);

        const address = await signer.getAddress();
        connectBtn.innerText = `${address.slice(0, 6)}...${address.slice(-4)}`;
        log("Connected! Note: Beneficiary must be a second MetaMask account.");
      } catch (err) {
        log("Error: " + (err.reason || err.shortMessage || err.message));
      }
    };
  }
});

// WRITE 1
async function createVault() {
  if (!contract) return alert("Connect wallet first!");
  const beneficiary = document.getElementById("beneficiaryAddr").value.trim();
  const interval = document.getElementById("intervalSec").value;
  const ethVal = document.getElementById("depositEth").value;

  try {
    clearInterval(timer);
    log("Confirm vault creation in MetaMask...");
    const tx = await contract.createVault(beneficiary, interval, {
      value: ethers.parseEther(ethVal)
    });
    const receipt = await tx.wait();

    for (const parsed of receipt.logs) {
      try {
        const event = contract.interface.parseLog(parsed);
        if (event && event.name === "VaultCreated") {
          document.getElementById("vaultId").value = event.args.vaultId.toString();
        }
      } catch (_) {}
    }

    log(`Vault #${document.getElementById("vaultId").value} created! Timer is now ticking.`);
  } catch (err) {
    log("Error: " + (err.reason || err.shortMessage || err.message));
  }
}

// READ 1 & READ 2
async function inspectVault() {
  if (!contract) return alert("Connect wallet first!");
  const id = document.getElementById("vaultId").value;
  clearInterval(timer);

  try {
    const [owner, beneficiary, balance, isClaimable, claimed] = await contract.getVaultDetails(id);
    let secondsLeft = Number(await contract.secondsUntilClaimable(id));
    const formattedEth = ethers.formatEther(balance);

    const render = () => {
      const state = claimed
        ? "CLAIMED (Vault Empty)"
        : (isClaimable || secondsLeft <= 0)
          ? "EXPIRED — READY FOR BENEFICIARY TO CLAIM"
          : `ACTIVE (${secondsLeft}s until claimable)`;

      log(
        `Vault #${id}\n` +
        `Owner:        ${owner}\n` +
        `Beneficiary:  ${beneficiary}\n` +
        `Balance:      ${formattedEth} ETH\n` +
        `Status:       ${state}`
      );
    };

    render();

    if (!claimed && secondsLeft > 0) {
      timer = setInterval(() => {
        secondsLeft--;
        render();
        if (secondsLeft <= 0) clearInterval(timer);
      }, 1000);
    }
  } catch (err) {
    log("Error: " + (err.reason || err.shortMessage || err.message));
  }
}

// WRITE 2
async function pingOrClaim() {
  if (!contract) return alert("Connect wallet first!");
  const id = document.getElementById("vaultId").value;

  try {
    clearInterval(timer);
    log("Submitting transaction...");
    const tx = await contract.pingOrClaim(id);
    await tx.wait();
    log("Transaction confirmed! Refreshing vault status...");
    inspectVault();
  } catch (err) {
    log("Error: " + (err.reason || err.shortMessage || err.message));
  }
}

function log(text) {
  document.getElementById("outputBox").innerText = text;
}
