# 🛡️ LegacyVault — Decentralized Dead-Man's Switch

**LegacyVault** is a decentralized inheritance and backup vault built on Ethereum. It allows a user to deposit ETH into a smart contract and assign a trusted beneficiary address along with an inactivity timer (heartbeat interval). As long as the vault owner periodically checks in ("pings"), the timer resets. If the owner becomes inactive and the timer expires, the designated beneficiary can claim the locked ETH.

---

## ✨ Key Features & Smart Contract Functions

The `LegacyVault.sol` smart contract implements **2 Write** and **2 Read** functions:

* **`createVault` (Write):** Locks an ETH deposit for a designated beneficiary with a custom inactivity duration (in seconds).
* **`pingOrClaim` (Write):** Dual-purpose action based on the caller:
  * If called by the **Owner**, it resets the heartbeat countdown timer.
  * If called by the **Beneficiary** after the countdown reaches `0`, it transfers the locked ETH to the beneficiary.
* **`getVaultDetails` (Read):** Retrieves the vault owner, beneficiary address, locked ETH balance, claimability status, and whether the vault has already been claimed.
* **`secondsUntilClaimable` (Read):** Returns the exact number of seconds remaining before the beneficiary can withdraw the funds.

---

## 📁 Project Structure

```text
LegacyVault/
├── contracts/
│   └── LegacyVault.sol          # Solidity smart contract (^0.8.20)
├── migrations/
│   └── 2_deploy_contracts.js    # Truffle deployment script
├── truffle-config.js            # Truffle network & compiler configuration
├── index.html                   # Frontend user interface
├── script.js                    # Web3 / Ethers.js v6 contract integration
└── README.md                    # Project documentation
```

---

## 🛠️ Prerequisites

* **Node.js** & **Truffle** (`npm install -g truffle`)
* **Ganache** (Desktop GUI on port `7545` or CLI on port `8545`)
* **MetaMask** browser extension
* A local web server (e.g., **XAMPP**, **VS Code Live Server**, or `npx serve`)

---

## 🚀 Setup & Installation Guide

### 1. Start Ganache
Open **Ganache** and start a workspace running on `http://127.0.0.1:7545` (Chain ID: `1337` or `5777`).

### 2. Compile & Deploy the Smart Contract
Run Truffle in your project root directory to deploy `LegacyVault.sol` to Ganache:

```bash
truffle compile
truffle migrate --reset
```

Copy the deployed contract address printed in the terminal output.

### 3. Configure the Frontend
Open `script.js` and replace `CONTRACT_ADDRESS` with your newly deployed contract address:

```javascript
const CONTRACT_ADDRESS = "0xYourDeployedContractAddressHere";
```

Make sure `index.html` and `script.js` are placed together in the same web directory (e.g., `C:\xampp\htdocs\ASSIGNMENT3\`).

### 4. Configure MetaMask
1. Open MetaMask and add a custom network:
   * **Network Name:** Ganache
   * **Default RPC URL:** `http://127.0.0.1:7545`
   * **Chain ID:** `1337` (or `5777` depending on your Ganache settings)
   * **Currency Symbol:** `ETH`
2. Import **two accounts** from Ganache into MetaMask using their private keys:
   * **Account 1:** Vault Owner
   * **Account 2:** Beneficiary

---

## 🧪 How to Test

1. Open `http://localhost/ASSIGNMENT3/` in your browser and click **Connect MetaMask** using **Account 1 (Owner)**.
2. Copy **Account 2's** wallet address and paste it into the **Beneficiary Wallet Address** field.
3. Set the **Heartbeat Interval** to `45` seconds and the **ETH Deposit Amount** to `0.001`, then click **Create Vault**.
4. Click **Check Vault (Read)** to watch the live countdown timer.
5. **Test Owner Check-In:** While connected as **Account 1**, click **Ping / Claim (Write)** before the timer hits `0`—the timer will reset back to `45` seconds.
6. **Test Beneficiary Claim:** Let the timer reach `0`, switch MetaMask to **Account 2 (Beneficiary)**, and click **Ping / Claim (Write)** to withdraw the ETH.