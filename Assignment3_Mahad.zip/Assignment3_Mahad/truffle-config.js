module.exports = {
  networks: {
    // Uncommented for local Ganache GUI (port 7545) or Ganache CLI (port 8545)
    development: {
      host: "127.0.0.1",     // Localhost
      port: 7545,            // Standard Ganache GUI port (change to 8545 if using ganache-cli)
      network_id: "*",       // Match any network id
    },
  },

  // Set default mocha options here, use special reporters, etc.
  mocha: {
    // timeout: 100000
  },

  // Uncommented and set to match `pragma solidity ^0.8.20;` in LegacyVault.sol
  compilers: {
    solc: {
      version: "0.8.20",     // Fetch exact version from solc-bin
      settings: {
        optimizer: {
          enabled: true,
          runs: 200
        },
      }
    }
  },
};