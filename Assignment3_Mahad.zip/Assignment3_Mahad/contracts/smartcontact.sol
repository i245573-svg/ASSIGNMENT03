// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract LegacyVault {
    error ZeroAmount();
    error InvalidBeneficiary();
    error InvalidInterval();
    error VaultNotFound();
    error AlreadyClaimed();
    error Unauthorized();
    error StillActive(uint256 secondsRemaining);
    error TransferFailed();

    struct Vault {
        address owner;
        address beneficiary;
        uint256 balance;
        uint256 checkInInterval;
        uint256 lastPing;
        bool claimed;
    }

    uint256 public vaultCount;
    mapping(uint256 => Vault) private vaults;

    event VaultCreated(uint256 indexed vaultId, address indexed owner, address indexed beneficiary, uint256 amount, uint256 interval);
    event HeartbeatPinged(uint256 indexed vaultId, uint256 nextDeadline);
    event VaultClaimed(uint256 indexed vaultId, address indexed beneficiary, uint256 amount);

    // WRITE FUNCTION 1: Create a vault with ETH, a beneficiary, and an inactivity period
    function createVault(address _beneficiary, uint256 _checkInIntervalSeconds) external payable returns (uint256) {
        if (msg.value == 0) revert ZeroAmount();
        if (_beneficiary == address(0) || _beneficiary == msg.sender) revert InvalidBeneficiary();
        if (_checkInIntervalSeconds == 0) revert InvalidInterval();

        uint256 id = vaultCount++;
        vaults[id] = Vault({
            owner: msg.sender,
            beneficiary: _beneficiary,
            balance: msg.value,
            checkInInterval: _checkInIntervalSeconds,
            lastPing: block.timestamp,
            claimed: false
        });

        emit VaultCreated(id, msg.sender, _beneficiary, msg.value, _checkInIntervalSeconds);
        return id;
    }

    // WRITE FUNCTION 2: Owner pings to reset timer OR Beneficiary claims after expiration
    function pingOrClaim(uint256 _vaultId) external {
        if (_vaultId >= vaultCount) revert VaultNotFound();
        Vault storage v = vaults[_vaultId];

        if (v.claimed) revert AlreadyClaimed();

        if (msg.sender == v.owner) {
            // Owner checks in -> reset the countdown
            v.lastPing = block.timestamp;
            emit HeartbeatPinged(_vaultId, block.timestamp + v.checkInInterval);
        } else if (msg.sender == v.beneficiary) {
            // Beneficiary attempts to claim -> check if deadline passed
            uint256 deadline = v.lastPing + v.checkInInterval;
            if (block.timestamp < deadline) {
                revert StillActive(deadline - block.timestamp);
            }

            v.claimed = true;
            uint256 payout = v.balance;
            v.balance = 0;

            (bool success, ) = payable(v.beneficiary).call{value: payout}("");
            if (!success) revert TransferFailed();

            emit VaultClaimed(_vaultId, v.beneficiary, payout);
        } else {
            revert Unauthorized();
        }
    }

    // READ FUNCTION 1: Get complete vault info and claim status
    function getVaultDetails(uint256 _vaultId) external view returns (
        address owner,
        address beneficiary,
        uint256 balance,
        bool isClaimable,
        bool claimed
    ) {
        if (_vaultId >= vaultCount) revert VaultNotFound();
        Vault memory v = vaults[_vaultId];

        bool claimable = !v.claimed && (block.timestamp >= v.lastPing + v.checkInInterval);
        return (v.owner, v.beneficiary, v.balance, claimable, v.claimed);
    }

    // READ FUNCTION 2: Seconds left before beneficiary can claim
    function secondsUntilClaimable(uint256 _vaultId) external view returns (uint256) {
        if (_vaultId >= vaultCount) revert VaultNotFound();
        Vault memory v = vaults[_vaultId];

        if (v.claimed) return 0;
        uint256 deadline = v.lastPing + v.checkInInterval;
        return block.timestamp >= deadline ? 0 : deadline - block.timestamp;
    }
}